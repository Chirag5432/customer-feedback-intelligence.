import streamlit as st
import pandas as pd
from src.analyzer import analyze_feedback
from src.storage import init_db, add_feedback, get_feedback, delete_all

st.set_page_config(page_title="Customer Feedback Intelligence", page_icon="📊", layout="wide")
init_db()

st.title("📊 Customer Feedback Intelligence")
st.caption("Turn customer messages into prioritized, actionable business insights.")

with st.sidebar:
    st.header("Add customer feedback")
    customer = st.text_input("Customer name (optional)")
    message = st.text_area("Feedback message", placeholder="Example: I was charged twice for my order...")
    channel = st.selectbox("Channel", ["Website", "Email", "App", "Phone", "Social Media"])
    if st.button("Analyze and save feedback", type="primary", use_container_width=True):
        if not message.strip():
            st.error("Please enter a feedback message.")
        else:
            result = analyze_feedback(message)
            add_feedback(customer.strip() or "Anonymous", message.strip(), channel, result)
            st.success("Feedback analyzed and saved.")

st.subheader("Business overview")
records = get_feedback()
if not records:
    st.info("No feedback yet. Add a message from the sidebar or load the sample data.")
    if st.button("Load sample feedback"):
        sample = [
            ("Asha", "I was charged twice and nobody has refunded me.", "App"),
            ("Ravi", "The delivery was late by three days. Very disappointed.", "Website"),
            ("Meena", "The support team solved my issue quickly. Thank you!", "Email"),
            ("Kiran", "The app crashes whenever I try to make a payment.", "App"),
            ("Sita", "Great service and easy checkout experience.", "Website"),
            ("Arjun", "I cannot reset my password. The reset link does not work.", "Email"),
        ]
        for name, msg, channel_name in sample:
            add_feedback(name, msg, channel_name, analyze_feedback(msg))
        st.rerun()
else:
    df = pd.DataFrame(records)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total feedback", len(df))
    c2.metric("High priority", int((df["priority"] == "High").sum()))
    c3.metric("Negative", int((df["sentiment"] == "Negative").sum()))
    c4.metric("Categories", int(df["category"].nunique()))

    left, right = st.columns(2)
    with left:
        st.markdown("**Feedback by category**")
        st.bar_chart(df["category"].value_counts())
    with right:
        st.markdown("**Sentiment breakdown**")
        st.bar_chart(df["sentiment"].value_counts())

    st.subheader("Feedback inbox")
    categories = ["All"] + sorted(df["category"].unique().tolist())
    selected = st.selectbox("Filter by category", categories)
    if selected != "All":
        df = df[df["category"] == selected]
    st.dataframe(
        df[["created_at", "customer", "channel", "message", "category", "sentiment", "priority", "suggestion"]],
        use_container_width=True,
        hide_index=True
    )
    st.download_button("Download filtered feedback as CSV",
                       df.to_csv(index=False).encode("utf-8"),
                       file_name="customer_feedback_report.csv",
                       mime="text/csv")
    with st.expander("How prioritization works"):
        st.write("Priority is estimated using transparent keyword rules. Urgent terms such as 'charged twice', 'fraud', 'cannot login', and 'payment failed' raise priority. This is a decision-support aid, not an automated final decision.")
    if st.button("Delete all feedback", type="secondary"):
        delete_all()
        st.rerun()
