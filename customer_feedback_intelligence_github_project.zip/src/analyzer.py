"""Transparent, explainable baseline analyzer for customer feedback."""

CATEGORY_KEYWORDS = {
    "Payment": ["payment", "charged", "refund", "billing", "invoice", "transaction", "card"],
    "Delivery": ["delivery", "delivered", "shipping", "late", "courier", "tracking", "order"],
    "Technical": ["app", "website", "crash", "error", "bug", "login", "password", "link", "slow"],
    "Customer Service": ["support", "agent", "staff", "service", "response", "call", "help"],
}

POSITIVE_WORDS = {"great", "good", "excellent", "thank", "thanks", "happy", "easy", "quick", "helpful", "love"}
NEGATIVE_WORDS = {"bad", "poor", "late", "angry", "disappointed", "broken", "failed", "fraud", "problem", "issue", "crash", "cannot", "unable", "wrong"}
URGENT_PHRASES = ["charged twice", "fraud", "payment failed", "cannot login", "account locked", "data leak", "not received", "stolen"]

SUGGESTIONS = {
    "Payment": "Check the transaction record, verify whether a duplicate charge occurred, and provide a clear refund status.",
    "Delivery": "Check shipment tracking, identify the delay point, and give the customer a realistic delivery update.",
    "Technical": "Reproduce the issue, capture error details, and route it to the technical team with steps to reproduce.",
    "Customer Service": "Review the conversation history and follow up with a clear owner and resolution timeline.",
    "General": "Review the message, clarify the customer's desired outcome, and assign an owner for follow-up.",
}

def analyze_feedback(message: str) -> dict:
    text = message.lower()
    words = set(text.replace(".", " ").replace(",", " ").replace("!", " ").split())

    scores = {
        category: sum(1 for keyword in keywords if keyword in text)
        for category, keywords in CATEGORY_KEYWORDS.items()
    }
    category = max(scores, key=scores.get) if max(scores.values(), default=0) else "General"

    positive = sum(1 for word in POSITIVE_WORDS if word in words)
    negative = sum(1 for word in NEGATIVE_WORDS if word in words)
    sentiment = "Positive" if positive > negative else "Negative" if negative > positive else "Neutral"

    urgent = any(phrase in text for phrase in URGENT_PHRASES)
    priority = "High" if urgent or (sentiment == "Negative" and len(text) > 100) else "Medium" if sentiment == "Negative" else "Low"

    return {
        "category": category,
        "sentiment": sentiment,
        "priority": priority,
        "suggestion": SUGGESTIONS[category],
    }
