import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "feedback.db"

def connect():
    return sqlite3.connect(DB_PATH)

def init_db():
    with connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                customer TEXT NOT NULL,
                message TEXT NOT NULL,
                channel TEXT NOT NULL,
                category TEXT NOT NULL,
                sentiment TEXT NOT NULL,
                priority TEXT NOT NULL,
                suggestion TEXT NOT NULL
            )
        """)

def add_feedback(customer, message, channel, result):
    with connect() as conn:
        conn.execute("""
            INSERT INTO feedback
            (created_at, customer, message, channel, category, sentiment, priority, suggestion)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            customer, message, channel, result["category"], result["sentiment"],
            result["priority"], result["suggestion"]
        ))

def get_feedback():
    import pandas as pd
    with connect() as conn:
        return pd.read_sql_query("SELECT * FROM feedback ORDER BY id DESC", conn).to_dict("records")

def delete_all():
    with connect() as conn:
        conn.execute("DELETE FROM feedback")
