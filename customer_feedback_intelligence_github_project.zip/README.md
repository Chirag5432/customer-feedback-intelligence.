# Customer Feedback Intelligence System

A small customer-operations product that converts unstructured feedback into categorized, prioritized work for a support team.

## Customer problem
Support teams often receive feedback across multiple channels. Manually sorting every message makes it harder to spot urgent issues, recurring problems, and opportunities to improve the customer experience.

## What this app does
- Captures feedback and its source channel.
- Assigns a category: Payment, Delivery, Technical, Customer Service, or General.
- Estimates sentiment and priority using explainable baseline rules.
- Suggests a next action for the support team.
- Shows a dashboard and lets users export filtered records to CSV.
- Stores records locally in SQLite.

## Important design decision
The analyzer is deliberately transparent and rule-based. It is a baseline decision-support tool, not a production-grade AI classifier. Keyword rules can misclassify sarcasm, context, and nuanced language. A future version could evaluate an AI model against a labeled test set, show confidence, and require human review for uncertain or high-impact decisions.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Open the local URL printed by Streamlit.

## Run tests
```bash
python -m unittest discover -s tests -v
```

## Example feedback to try
- "I was charged twice and nobody has refunded me."
- "The delivery was late by three days. Very disappointed."
- "The support team solved my issue quickly. Thank you!"
- "The app crashes whenever I try to make a payment."

## Repository structure
```text
customer-feedback-intelligence/
├── app.py
├── src/
│   ├── __init__.py
│   ├── analyzer.py
│   └── storage.py
├── tests/
│   └── test_analyzer.py
├── requirements.txt
├── .gitignore
└── README.md
```

## Product decisions and trade-offs
1. **Local SQLite:** simple setup for a portfolio demo; production use would need managed storage, backups, access control, and retention policies.
2. **Explainable rules:** easy to inspect and test; less accurate than a well-evaluated language model.
3. **Human ownership:** recommendations are suggestions. A support agent remains responsible for customer-facing decisions.
4. **CSV export:** makes the output useful to teams that already work in spreadsheets.

## Future improvements
- Add customer login and role-based access.
- Add a feedback search and duplicate-issue detection feature.
- Add a human correction workflow and collect labeled examples.
- Compare a machine-learning or LLM classifier against the baseline using precision, recall, and a held-out test set.
- Track time-to-resolution and customer satisfaction.

## Portfolio demo checklist
- [ ] Run the app and load sample feedback.
- [ ] Add one original feedback example.
- [ ] Run the unit tests.
- [ ] Take screenshots of the dashboard and feedback inbox.
- [ ] Explain one limitation and one improvement you would prioritize.
