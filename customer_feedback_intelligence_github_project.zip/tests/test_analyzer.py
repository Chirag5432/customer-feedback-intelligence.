import unittest
from src.analyzer import analyze_feedback

class AnalyzerTests(unittest.TestCase):
    def test_payment_urgent(self):
        result = analyze_feedback("I was charged twice and need a refund.")
        self.assertEqual(result["category"], "Payment")
        self.assertEqual(result["priority"], "High")

    def test_positive_feedback(self):
        result = analyze_feedback("Great service, thank you for the quick help!")
        self.assertEqual(result["sentiment"], "Positive")

    def test_technical_category(self):
        result = analyze_feedback("The app crashes and I cannot login.")
        self.assertEqual(result["category"], "Technical")

if __name__ == "__main__":
    unittest.main()
